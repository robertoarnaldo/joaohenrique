INSERT INTO ALUNO(nome,idade) VALUES('Roberto','1972-08-15');
INSERT INTO ALUNO(nome,idade) VALUES('Lucas','2003-09-13');
INSERT INTO ALUNO(nome,idade) VALUES('Matheus Antonio','2017-06-15');